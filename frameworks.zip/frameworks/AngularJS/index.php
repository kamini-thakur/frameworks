
	<table border="1" id="showUsers" class="table table-hover" hidden>
		<tr><th>First name</th><th>Last name</th><th>Password</th><th>Mobile number</th><th>Gender</th></tr>
		<tr ng-repeat="detail in details">
			<td>{{ detail.fname }}</td>
			<td>{{ detail.lname }}</td>
			<td>{{ detail.password }}</td>
			<td>{{ detail.mobileNo }}</td>
			<td>{{ detail.gender }}</td>
		</tr>


	</table>
	