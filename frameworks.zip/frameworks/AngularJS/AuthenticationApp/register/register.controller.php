<?php 

require_once '../config.php';

$data = json_decode(file_get_contents("php://input"));
$fname = $data->fname;
$lname = $data->lname;
$user_email = $data->user_email;
$password = $data->password;
$mobileNo = $data->mobileNo;
$gender = $data->gender;

$sql = "SELECT * from user where user_email='$user_email' ";
    //echo 'hello'.$uname;
$qex = mysqli_query($con, $sql);
$num_rows=mysqli_num_rows($qex);

if($num_rows == 0)
{
    $query = "INSERT INTO user(fname,lname,user_email,password,mobileNo,gender)VALUES('".$fname."','".$lname."','".$user_email."','".$password."','".$mobileNo."','".$gender."')";
    $qex1 = mysqli_query($con, $query);
    if(!$qex1)
    {
        echo 'error';
    }
    else
    {
        echo 'true';
    }
}
else
{
    $response_code = 404;
    echo $response_code;
}


?>