<?php

$con=mysqli_connect("localhost","root","esfera","angular");
if(mysqli_connect_errno())
{
	echo "connection failed";
}
session_start();

?>