
<?php

require_once '../config.php';

unset($_SESSION['user_id']);
unset($_SESSION['fname']);
session_unset();
session_destroy();
if(isset($_SESSION['user_id']))
{
	$response_code = 404;
	echo $response_code;	
}
else
{
	//mysql_close($con);
	$response_code = 200;
	echo $response_code;
}

?>
