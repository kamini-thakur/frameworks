<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>AngularJS User Registration and Login Example & Tutorial</title>

     <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>


    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular-route.js"></script>

    <script src="app.js"></script>

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    

</head>
<body ng-app="myApp">
    <h2 align="center">My Angular JS application</h2>
    <nav class="navbar navbar-default" ng-controller="mainNav">
        <div class="navbar-header">
        <div class="alert alert-default navbar-brand search-box">

        <a href="#home"><button class="btn btn-primary">Home<span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></a>

        </div>
        <div class="alert alert-default navbar-brand search-box">

        <a href="#register"><button class="btn btn-primary">Register<span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></a>

        </div>

        <div class="alert alert-default navbar-brand search-box" id="ShowOnLogin"></div>

        <div class="alert alert-default navbar-brand search-box ng-hide" id="logOut">
         <button class="btn btn-primary"  ng-click="logout()">Log-out <span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
        </div>
        
        <div class="alert alert-default navbar-brand search-box" id="logIn">
        <a href="#login"><button class="btn btn-primary">Log-in <span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></a>
        </div>

        </div>
    </nav>
    <div class="jumbotron">
        <div class="container">
            <div class="col-sm-8 col-sm-offset-2">
                <div ng-class="{ 'alert': flash, 'alert-success': flash.type === 'success', 'alert-danger': flash.type === 'error' }" ng-if="flash" ng-bind="flash.message"></div>
                <div class="clearfix"></div>
                <div ng-view></div>
            </div>
        </div>
    </div>
    
    

</body>
</html>