

<?php
require_once '../config.php';
$data = json_decode(file_get_contents("php://input"));
$query = "DELETE FROM blogs WHERE blog_id=$data->del_id";
$result=mysqli_query($con, $query);
if($result)
{
	$response_code = 200;
	echo $response_code;
}
else
{
	$response_code = 404;
	echo $response_code;
}
?>

