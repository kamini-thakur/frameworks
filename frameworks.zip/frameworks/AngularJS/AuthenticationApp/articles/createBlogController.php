
<?php 

require_once '../config.php';
$data = json_decode(file_get_contents("php://input"));
$blog_title = $data->blog_title;
$blog_content = $data->blog_content;
 

	$query = "INSERT INTO blogs(blog_title,blog_content,user_id)VALUES('".$blog_title."','".$blog_content."','".$_SESSION['user_id']."')";
	$qex1 = mysqli_query($con, $query);
	if(!$qex1)
	{
		$response_code = 404;
		echo $response_code;
	}
	else
	{
		$response_code = 200;
		echo $response_code;
	}


?>

