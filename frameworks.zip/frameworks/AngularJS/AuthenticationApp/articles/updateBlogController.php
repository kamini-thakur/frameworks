

<?php
require_once '../config.php';
$data = json_decode(file_get_contents("php://input"));
$blog_id = $data->blog_id;
$blog_title = $data->blog_title;
$blog_content = $data->blog_content;

// mysqli query to insert the updated data
$query = "UPDATE blogs SET blog_title='$blog_title',blog_content='$blog_content' WHERE blog_id=$blog_id";
$qex=mysqli_query($con, $query);
if(!$qex)
	{
		//echo 'error';
		$response_code = 404;
		echo $response_code;
	}
	else
	{
		$response_code = 200;
		echo $response_code;
	}
?>

