	
var app = angular.module('myApp',[]);
app.controller('regController',function($scope,$http){	
	
	getUsers();
	function getUsers()
	{
		// Sending request to EmpDetails.php files
			$http.post('userRegister/userDetails.php').success(function(data){
			// Stored the returned data into scope
			console.log(data);
			$scope.details = data;
			});
	}
	
	$scope.insertInfo=function(info){		
	$http.post("userRegister/userRegController.php", {
			'fname':info.fname,
			'lname':info.lname,
			'user_email':info.user_email,
			'password':info.password,
			'mobileNo':info.mobileNo,
			'gender':info.gender}).then(function(response){
                    //console.log(response.data);
                    if (response.data == 404) {
                    	alert("User with this email already exists");
						//getUsers();
						// Hide details insertion form
						//$('#userForm').css('display', 'none');
						//$("form#userForm")[0].reset();
					}
					else
					{
						alert("Registered successfully");
						$("form#userForm")[0].reset();
					}
                },function(error){
                    alert("Sorry! Data Couldn't be inserted!");
                    console.error(error);

                });
	}

	$scope.login=function(info){		
	$http.post("userLogin/loginController.php", {
			'user_email':info.user_email,
			'password':info.password}).then(function(response){
                    console.log("Data sent to check user exist or not");
                    if (response.data == 200) {
						$('#loginForm').css('display', 'none');		
						 $window.location.href = 'userHome/allPostView.php';
					}
                },function(error){
                    alert("Wrong uesrname or password");
                    console.error(error);

                });
	}

	$scope.formToggle = function(info){	
		$('#loginForm').slideUp();
		$('#userForm').slideToggle();
	}
	$scope.formLog = function(info){
		$('#userForm').slideUp();	
		$('#loginForm').slideToggle();
	}
	/*
	$scope.showBlog() = function(info){
		$('#userForm').slideUp();	
		$('#loginForm').slideToggle();
	}*/

});
