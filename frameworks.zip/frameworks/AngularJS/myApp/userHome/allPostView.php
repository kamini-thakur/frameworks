<!-- 

<form method="post" id="createBlog" ng-submit="AllBlog(info);" hidden>
	<input type="text" name="blogTitle" ng-model="info.blogTitle" placeholder="Blog Title"><br><br>
	<input type="text" name="blogContent" ng-model="info.blogContent" placeholder="Blog Content"><br><br>
	<input type="submit" value="Save Article">
</form> -->

<h1>Hi {{ userInfo.fname }}!</h1>
<p>You're logged in!!</p>
<h3>All registered users:</h3>

<p><a href="#!/login" class="btn btn-primary">Logout</a></p>