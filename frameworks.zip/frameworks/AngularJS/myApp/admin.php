
<!DOCTYPE html>
<html ng-app="adminApp">
<head>
	<title></title>

	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
	
</head>
<body>
<div  ng-controller="adminController">
	<form method="post" id="loginForm">
		<input type="text" ng-model="uname" placeholder="Username"><br><br>
		<input type="text" ng-model="paswd" placeholder="Password"><br><br>
		<input type="submit" ng-click="login()">
	</form>

	<div ng-include src="'templates/allUser.html'"></div>
	
</div>

<script>
		var app = angular.module('adminApp',[]);
	    app.controller('adminController',function($scope,$http){	
	    $scope.login=function(){		
	    $http.post("login.php", {
			'uname':$scope.uname,
			'paswd':$scope.paswd}).success(function(data){
				// Stored the returned data into scope
				if(data == 200)
				{
					console.log(data);
					//$window.location.href = '/templates/index.php';
					//$location.path('/templates/index.php');
					getUsers();
				}
				
				//console.log('Data successfully sent');
				});
	        }

	   
		function getUsers(){
		// Sending request to EmpDetails.php files
			$http.post('userDetails.php').success(function(data){
			// Stored the returned data into scope
			console.log(data);
			$scope.details = data;
			});
		}

	         });
	</script>

</body>
</html>