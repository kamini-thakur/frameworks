	<form class="form-horizontal alert alert-warning" name="empList" id="userForm" ng-submit="insertInfo(userInfo);" hidden>
		<input type="text" name="fname" ng-model="userInfo.fname" placeholder="Firstname"><br><br>
		<input type="text" name="lname" ng-model="userInfo.lname" placeholder="Lastname"><br><br>
		<input type="email" name="user_email" ng-model="userInfo.user_email" placeholder="Email"><br><br>
		<input type="password" name="password" ng-model="userInfo.password" placeholder="Password"><br><br>
		<input type="number" name="mobileNo" ng-model="userInfo.mobileNo" placeholder="Mobile number" min="0"><br><br>
		<input type="radio" name="gender" ng-model="userInfo.gender" value="male">Male
		<input type="radio" name="gender" ng-model="userInfo.gender" value="female">Female
		<input type="submit" value="Submit">
	</form>
