
<html ng-app="myApp">
<head>
<title>AngularJS Directive Demo</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Include Bootstrap CSS -->

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>


</head>
<body>
<div class="container wrapper" ng-controller="regController">
<h1 class="text-center"></h1>
<nav class="navbar navbar-default">
<div class="navbar-header">
<div class="alert alert-default navbar-brand search-box">

<button class="btn btn-primary" ng-click="formToggle()">Register <span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>

</div>
<div class="alert alert-default navbar-brand search-box">

<button class="btn btn-primary" ng-click="formLog()">Log-in <span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>

</div>


</div>
</nav>
<div class="col-md-6 col-md-offset-3">

<!-- Include form template which is used to insert data into database -->
<div ng-include src="'userRegister/usersView.php'"></div>

<!-- Include form template which is used to edit and update data into database -->
<div ng-include src="'userLogin/userLogin.php'"></div> 
</div>
<div class="clearfix"></div>

<!-- Table to show employee detalis -->
<div class="table-responsive">
<table class="table table-hover">
<tr><th>First name</th><th>Last name</th><th>Email</th><th>Gender</th></tr>
<tr ng-repeat="detail in details">
			<td>{{ detail.fname }}</td>
			<td>{{ detail.lname }}</td>
			<td>{{ detail.user_email }}</td>
			<td>{{ detail.gender }}</td>
</tr>
</table>
</div>

<div id="userPanel" style="display: none;">

<button class="btn btn-primary" ng-click="showBlog()">Add post<span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
<div ng-include src="'userRegister/usersView.php'"></div>

</div>

</div>
<!--
<div ng-include src="'userRegister/userHome.php'"></div>
-->


<!-- Include controller -->
<script src="js/angular-script.js"></script>
</body>
</html>



