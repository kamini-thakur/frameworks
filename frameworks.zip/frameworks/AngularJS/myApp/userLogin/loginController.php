
<?php 
require_once "../config.php";

$data = json_decode(file_get_contents("php://input"));
$user_email = $data->user_email;
$password = $data->password;
$sql = "SELECT * from user where user_email='$user_email' and password='$password'";
	//echo 'hello'.$uname;
	$qex = mysqli_query($con, $sql);
	if(!$qex)
	{
		echo 'Not working';
	}
	$num_rows=mysqli_num_rows($qex);
	$res=mysqli_fetch_array($qex);
	if($num_rows == 0)
	{
		alert("Wrong username or Password");
		$response_code = 404;
		echo $response_code;
	}
	else
	{
		//echo 'right';
		$response_code = 200;
		echo $response_code;
		//echo 'login successful';
		$_SESSION['fname'] = $res['fname'];
		$_SESSION['user_id'] = $res['user_id'];
		
		//echo $_SESSION['fname'];
		//echo $_SESSION['uname'];
		//header("Location: index.php");
		//exit;
		/*
		*/
		//print_r($arr);
	}

?>

