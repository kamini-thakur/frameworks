<!-- Table to show employee detalis -->
<div class="table-responsive">
<table class="table table-hover">
<tr><th>First name</th><th>Last name</th><th>Email</th><th>Gender</th></tr>
<tr ng-repeat="detail in details">
			<td>{{ detail.fname }}</td>
			<td>{{ detail.lname }}</td>
			<td>{{ detail.user_email }}</td>
			<td>{{ detail.gender }}</td>
</tr>
</table>
</div>

<div id="userPanel" style="display: none;">

<button class="btn btn-primary" ng-click="">Add post<span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
<div ng-include src="'userRegister/usersView.php'"></div>

</div>


<!-- Include controller -->

</body>
</html>



