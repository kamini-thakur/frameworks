<form method="post" id="loginForm" ng-submit="login(info);" hidden>
	<input type="email" ng-model="info.user_email" placeholder="Username"><br><br>
	<input type="password" ng-model="info.password" placeholder="Password"><br><br>
	<input type="submit" value="Submit"  class="btn btn-danger">
</form>


  