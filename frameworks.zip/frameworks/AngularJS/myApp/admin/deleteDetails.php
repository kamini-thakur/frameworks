

<?php

require_once 'config.php';
$data = json_decode(file_get_contents("php://input"));
$delete_id = $data->del_id;
$query = "DELETE FROM user WHERE user_id=$delete_id";

$qex=mysqli_query($con, $query);
if(!$qex)
	{
		//echo 'error';
		$response_code = 404;
		echo $response_code;
	}
	else
	{
		$response_code = 200;
		echo $response_code;
	}

?>

