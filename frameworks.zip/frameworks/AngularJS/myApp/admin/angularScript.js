	
var app = angular.module('myAdminApp',[]);
app.controller('AdminController',function($scope,$http){	

	/*
	$scope.insertInfo=function(info){		
	$http.post("userRegister/userRegController.php", {
			'fname':info.fname,
			'lname':info.lname,
			'password':info.password,
			'mobileNo':info.mobileNo,
			'gender':info.gender}).then(function(response){
                    console.log("Data Inserted Successfully");
                    if (response == 'true') {
						getUsers();
						// Hide details insertion form
						$('#userForm').css('display', 'none');
					}
                },function(error){
                    alert("Sorry! Data Couldn't be inserted!");
                    console.error(error);

                });
	} */

	$scope.adminLogin=function(info){		
	$http.post("AdminLoginController.php", {
			'uname':info.uname,
			'paswd':info.paswd}).then(function(response){
                    console.log(response.data);
                    if (response.data == 200) {
						console.log('Successfully logged-in');
						$('#AdminHome').css('display', 'block');
						$scope.show_form = true;
						getUsers();
					}
					else
					{
						alert('Wrong username or password');
					}
                },function(error){
                    alert("Sorry! Data Couldn't sent!");
                    console.error(error);

                });
	}
	$scope.insertInfo=function(info){		
	$http.post("../userRegister/userRegController.php", {
			'fname':info.fname,
			'lname':info.lname,
			'user_email':info.user_email,
			'password':info.password,
			'mobileNo':info.mobileNo,
			'gender':info.gender}).then(function(response){
                    //console.log(response.data);
                    if (response.data == 404) {
                    	alert("User with this email already exists");
					}
					else
					{
						alert("Registered successfully");
						$("form#userForm")[0].reset();
						// Hide details insertion form
						$('#userForm').css('display', 'none');	
						getUsers();
						$('#AdminLogin').slideUp();
					}
                },function(error){
                    alert("Sorry! Data Couldn't be inserted!");
                    console.error(error);

                });
	}

	$scope.currentUser = {};
	$scope.editInfo = function(info){
		//alert('yes');
		$scope.currentUser = info;
		console.log(info);
		$('#userForm').slideUp();
		$('#AdminLogin').slideUp();
		$('#editForm').slideToggle();
	}

	$scope.UpdateInfo = function(info){
		alert('working');
		$http.post('updateDetails.php', {
			"user_id":info.user_id,
			"fname":info.fname,
			"lname":info.lname,
			"user_email":info.user_email,
			"password":info.password,
			"mobileNo":info.mobileNo,
			"gender":info.gender}).success(function(response){
				
				console.log(data);
				if (response.data == 200) {
					getUsers();
				}
			});
	}

	$scope.deleteInfo = function(info){
		$http.post('deleteDetails.php',{"del_id":info.user_id}).success(function(response){
			if (response.data == 200) {
				getUsers();
			}
		});
	}

	function getUsers()
	{
		// Sending request to EmpDetails.php files
			$http.post('allUsers/allUsersView.php').success(function(data){
			// Stored the returned data into scope
			//console.log(data);
			$scope.details = data;
			});
	} 

	$scope.formToggle = function(info){	
		//$('#loginForm').slideUp();
		$('#userForm').slideToggle();
		//$('#AdminLogin').slideUp();
		$('#editForm').slideUp();
	}

});
