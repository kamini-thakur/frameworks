
<?php 
require_once "config.php";

$data = json_decode(file_get_contents("php://input"));
$uname = $data->uname;
$paswd = $data->paswd;
$sql = "SELECT * from admin where uname='$uname' and paswd='$paswd'";
	//echo 'hello'.$uname;
	$qex = mysqli_query($con, $sql);

	$num_rows=mysqli_num_rows($qex);
	$res=mysqli_fetch_array($qex);
	//echo $num_rows;
	if($num_rows == 0)
	{
		$response_code = 404;
		echo $response_code;	
	}
	else
	{
		$response_code = 200;
		echo $response_code;
		
		// $_SESSION['uname'] = $res['uname'];
		// $_SESSION['id'] = $res['id'];
		//echo $_SESSION['uname'];
		//header("Location: index.php");
		//exit;
		/*
		*/
		//print_r($arr);
		
	}

?>

