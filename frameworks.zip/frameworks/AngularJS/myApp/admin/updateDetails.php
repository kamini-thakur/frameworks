

<?php
require_once 'config.php';
$data = json_decode(file_get_contents("php://input"));
$user_id = $data->user_id;
$fname = $data->fname;
$lname = $data->lname;
$user_email = $data->user_email;
$password = $data->password;
$mobileNo = $data->mobileNo;
$gender = $data->gender;

// mysqli query to insert the updated data
$query = "UPDATE user SET fname='$fname',lname='$lname',user_email='$user_email',password='$password',mobileNo='$mobileNo',gender='$gender' WHERE user_id=$user_id";
$qex=mysqli_query($con, $query);
if(!$qex)
	{
		//echo 'error';
		$response_code = 404;
		echo $response_code;
	}
	else
	{
		$response_code = 200;
		echo $response_code;
	}
?>

