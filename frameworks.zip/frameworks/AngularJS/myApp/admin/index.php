
<html ng-app="myAdminApp">
<head>
<title>AngularJS Directive Demo</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Include Bootstrap CSS -->

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>


</head>
<body>
<div class="container wrapper" ng-controller="AdminController">

<div class="col-md-5 col-md-offset-4">
<h1>Admin Log-in</h1>
<form method="post" id="AdminLogin" ng-submit="adminLogin(info);">
	<input type="text" ng-model="info.uname" placeholder="Username"><br><br>
	<input type="text" ng-model="info.paswd" placeholder="Password"><br><br>
	<input type="submit" value="Submit">
</form>
</div>

<div class="clearfix"></div>

<div class="alert alert-default navbar-brand search-box">

<button class="btn btn-primary" ng-show="show_form" ng-click="formToggle()">Add new user <span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>

</div>

<div class="col-md-5 col-md-offset-3">
<!-- Include form template which is used to insert data into database -->
<div ng-include src="'../userRegister/usersView.php'"></div>
<div ng-include src="'editForm.html'"></div>

</div>

<div class="clearfix"></div>

<div id="AdminHome" style="display: none;">
<h1>All Users</h1>
<table class="table table-hover">
<tr><th>Id</th><th>First name</th><th>Last name</th><th>Email</th><th>Password</th><th>Mobile No.</th><th>Gender</th><th colspan="2">Actions</th></tr>
<tr ng-repeat="detail in details">
			<td>{{ detail.user_id }}</td>
			<td>{{ detail.fname }}</td>
			<td>{{ detail.lname }}</td>
			<td>{{ detail.user_email }}</td>
			<td>{{ detail.password }}</td>
			<td>{{ detail.mobileNo }}</td>
			<td>{{ detail.gender }}</td>

			<td>
			<button class="btn btn-warning" ng-click="editInfo(detail)" title="Edit"><span class="glyphicon glyphicon-edit"></span></button>
			</td>
			<td>
			<button class="btn btn-danger" ng-click="deleteInfo(detail)" title="Delete"><span class="glyphicon glyphicon-trash"></span></button>
			</td>

</tr>
</table>	
</div>


</div> <!-- container close -->

<!-- Include controller -->
<script src="angularScript.js"></script>
</body>
</html>



