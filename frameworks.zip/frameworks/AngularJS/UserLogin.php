==================users.html======================
<?php
include("config.php");
if(isset($_POST['Register']))
{
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$password = $_POST['password'];
	$mobileNo = $_POST['mobileNo'];
	$gender = $_POST['gender'];

	$sql = "INSERT INTO user(fname,lname,password,mobileNo,gender)VALUES('".$fname."','".$lname."','".$password."','".$mobileNo."','".$gender."')";
	$qex = mysqli_query($con, $sql);
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>

</head>
<body>
	<form method="post" action="#" id="myForm">
		<input type="text" name="fname" placeholder="Firstname"><br><br>
		<input type="text" name="lname" placeholder="Lastname"><br><br>
		<input type="password" name="password" placeholder="Password"><br><br>
		<input type="number" name="mobileNo" placeholder="Mobile number" min="0"><br><br>
		<input type="radio" name="gender" value="male">Male
		<input type="radio" name="gender" value="female">Female
		<input type="submit" name="Register">
	</form>
</body>
</html>

===================config.php==================
<?php
$con=mysqli_connect("localhost","root","esfera","angular");
if(mysqli_connect_errno())
{
	echo "connection failed";
}
session_start();

?>

=====================admin.php=======================
<?php
include("config.php");
if(isset($_POST['login']))
{
	$uname = $_POST['uname'];
	$paswd = $_POST['paswd'];

	$sql = "SELECT * from admin where uname='$uname' and paswd='$paswd'";
	//echo 'hello'.$uname;
	$qex = mysqli_query($con, $sql);
	$num_rows=mysqli_num_rows($qex);
	$res=mysqli_fetch_array($qex);
	if($num_rows == 0)
	{
		echo "Wrong username or Password";
	}
	else
	{
		
		$_SESSION['uname'] = $res['uname'];
		//echo $_SESSION['uname'];
		header("Location: all.php");
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>

</head>
<body>
	<form method="post" action="#">
		<input type="text" name="uname" placeholder="Username"><br><br>
		<input type="text" name="paswd" placeholder="Password"><br><br>
		<input type="submit" name="login">
	</form>
</body>
</html>

===============================all.php==============================
<?php
	include("config.php");
	if($_SESSION['uname'])
	{	
		$sql1 = "SELECT * from user";
		$qex1 = mysqli_query($con, $sql1);
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>

</head>
<body>
	
	<table border="1">
		<tr><th>First name</th><th>Last name</th><th>Password</th><th>Mobile number</th><th>Gender</th></tr>
		<?php
		while($res = mysqli_fetch_array($qex1))
		{
			?>
			<tr><td><?php echo $res['fname']; ?></td><td><?php echo $res['fname']; ?></td><td><?php echo $res['fname']; ?></td><td><?php echo $res['fname']; ?></td><td><?php echo $res['fname']; ?></td></tr>
			<?php
		}
		?>


	</table>


</body>
</html>