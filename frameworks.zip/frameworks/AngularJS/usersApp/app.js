var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
            $routeProvider.when('/', {
                controller: 'HomeController',
                templateUrl: 'home/home.view.html'
            })

            .when('/home', {
                controller: 'HomeController',
                templateUrl: 'home/home.view.html'
            })

            .when('/login', {
                controller: 'LoginController',
                templateUrl: 'login/login.view.html'
            })

            .when('/register', {
                controller: 'RegisterController',
                templateUrl: 'register/register.view.html'
            })

            .when('/welcome', {
                controller: 'WelcomeController',
                templateUrl: 'articles/userHome.html'
            })

            .otherwise({ redirectTo: 'login' });
});
app.controller('mainNav',function($scope,$http,$location){
    $scope.logout = function(info)
    {
            //alert('jj');
            $http.post('login/logout.controller.php').success(function(data){
            console.log(data);
            if(data == 200)
            {
                alert("Logged-out successfully");
                $location.path('/login');
                $('#logIn').addClass('ng-show').removeClass('ng-hide');
                $('#logOut').addClass('ng-hide').removeClass('ng-show');
                $('#ShowOnLogin').addClass('ng-hide');
            }
            });
    }
});
app.controller('HomeController',function($scope,$http){
    getAllBlogs();
    function getAllBlogs()
    {
        // Sending request to EmpDetails.php files
            $http.post('home/home.controller.php').success(function(data)           {
            // Stored the returned data into scope
            console.log(data);
            //console.log(response.user);
            $scope.details = data;
            });
    }
});

app.controller('RegisterController',function($scope,$http,$location){
    
    //alert('working');
    $scope.insertInfo=function(info){       
    $http.post("register/register.controller.php", {
            'fname':info.fname,
            'lname':info.lname,
            'user_email':info.user_email,
            'password':info.password,
            'mobileNo':info.mobileNo,
            'gender':info.gender}).then(function(response){
                    //console.log(response.data);
                    if (response.data == 404) {
                        alert("User with this email already exists");
                    }
                    else
                    {
                        alert("Registered successfully");
                        $("form#userForm")[0].reset();
                        console.log(data.data['fname']);
                         $('#logIn').addClass('ng-hide');
                         $('#logOut').addClass('ng-show').removeClass('ng-hide');
                         $('#ShowOnLogin').removeClass('ng-hide').html('<h3>Welcome '+data.data['fname']+'</h3>');
                        $location.path('/welcome');

                    }
                },function(error){
                    alert("Sorry! Data Couldn't be inserted!");
                    console.error(error);

                });
    }
});

app.controller('LoginController',function($scope,$http,$location){
$scope.login=function(info){        
    $http.post("login/login.controller.php", {
            'user_email':info.user_email,
            'password':info.password}).then(function(data){
                    console.log("Data sent to check user exist or not");
                    
                    if (data.data['response_code'] == 200) {
                         alert("Successfully logged-in");
                         console.log(data.data['fname']);
                         $('#logIn').addClass('ng-hide');
                         $('#logOut').addClass('ng-show').removeClass('ng-hide');
                         $('#ShowOnLogin').removeClass('ng-hide').html('<h3>Welcome '+data.data['fname']+'</h3>');
                         $location.path('/welcome');
                        
                    }
                },function(error){
                    alert("Wrong uesrname or password");
                    console.error(error);

                });
    }
});

app.controller('WelcomeController',function($scope,$http,$location){
    getUserBlogs();
    $scope.addNewBlog=function(info){  

    $http.post("articles/createBlogController.php", {
            'blog_title':info.blog_title,
            'blog_content':info.blog_content}).then(function(response){
                    console.log(response.data);
                    if (response.data == 200) 
                    {
                        alert("Blog added successfully");
                        getUserBlogs();
                        $("form#addBlog")[0].reset();
                    }
                    else
                    { 
                        alert("Blog addition failed");
                    }
                },function(error){
                    alert("Sorry! Data Couldn't be inserted!");
                    console.error(error);

                });
    }
   
    $scope.logout=function(info)
    {
            alert('jj');
            $http.post('login/logout.controller.php').success(function(data){
            console.log(data);
            alert("Logged-out successfully");
            $location.path('/login');
            });
    }
    $scope.addBlog = function(info){ 
        $('#addBlog').slideToggle();
    }
    $scope.deleteInfo = function(info){
        $http.post('articles/deleteBlogController.php',{"del_id":info.blog_id}).success(function(response){
            //console.log(response);
            if (response == 200) 
            {   
                alert("Blog deleted successfully");
                getUserBlogs();
            }
        });
    }
    function getUserBlogs()
    {
        // Sending request to EmpDetails.php files
            $http.post('articles/allBlogsController.php').success(function(data){
            // Stored the returned data into scope
            console.log(data);
            $scope.details = data;
            });
    }
    $scope.currentUser = {};
    $scope.editInfo = function(info){
        //alert('yes');
        $scope.currentBlog = info;
        console.log(info);
        $('#addBlog').slideUp();
        $('#editForm').slideToggle();
    }

    $scope.UpdateBlog = function(info){
        alert('working');
        $http.post('articles/updateBlogController.php', {
            "blog_id":info.blog_id,
            'blog_title':info.blog_title,
            'blog_content':info.blog_content}).success(function(response){
                
                console.log(response);
                if (response == 200) {
                    getUserBlogs();
                    $("form#editForm")[0].reset();
                    $('#editForm').slideUp();
                }
            });
    }
});

   

